package kz.sdu.milleniumbot.app.user;

import org.springframework.stereotype.Component;
import org.telegram.telegrambots.bots.TelegramLongPollingBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.CallbackQuery;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


@Component
public class Bot extends TelegramLongPollingBot {
    public static final String TOKEN = "1421074097:AAEcInRtS3iRAK5almCc3iXsQAryGFTe3Ac";
    public static final String USERNAME = "MiLearnBot";
    public static URL WIKI_URL, MEDIA_URL;
    private final UserRepository userRepository;

    static {
        try {
            WIKI_URL = new URL("https://en.wikipedia.org/wiki/Special:Random");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }
    static {
        try {
            MEDIA_URL = new URL("https://www.mediawiki.org/wiki/Special:Random");
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

    public Bot(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public void onUpdateReceived(Update update) {
        if (update.hasMessage()) {
            if (update.getMessage().hasText()) {
                if (update.getMessage().getText().equals("/menu") || update.getMessage().getText().equals("/menu@MilLearnBot")) {
                    try {
                        execute(sendInlineKeyBoardMessage(update.getMessage().getChatId()));
                    } catch (TelegramApiException e) {
                        e.printStackTrace();
                    }
                } else if (update.getMessage().getText().equals("/subjects")) {
                    try {
                        InlineKeyboardMarkup inlineKeyboardMarkup = new InlineKeyboardMarkup();
                        List<InlineKeyboardButton> inlineKeyboardButtonsRowOne = createSubjectButtons();
                        inlineKeyboardMarkup.setKeyboard(List.of(inlineKeyboardButtonsRowOne));
                        execute(new SendMessage(update.getMessage().getChatId(), "Choose subjects").setReplyMarkup(inlineKeyboardMarkup));
                    } catch (TelegramApiException e) {
                        e.printStackTrace();
                    }
                } else if (enumContains(update.getMessage().getText())) {
                    User user = userRepository.getByChatId(update.getMessage().getChatId().intValue()).orElseGet(() -> userRepository.save(User.builder().chatId(update.getMessage().getChatId().intValue()).build()));
                    Subject subject = Subject.valueOf(update.getMessage().getText());
                    Subject[] subjects = user.getSubject();
                    ArrayList<Subject> subjectList = (ArrayList<Subject>) List.of(subjects);
                    if (subjectList.contains(subject)) {
                        subjectList.remove(subject);
                    } else {
                        subjectList.add(subject);
                    }
                    Subject[] subs = subjectList.toArray(Subject[]::new);
                    user.setSubject(subs);
                    userRepository.save(user);
                }
            }
        } else if (update.hasCallbackQuery()) {
            try {
                execute(new SendMessage().setText(
                        update.getCallbackQuery().getData())
                        .setChatId(update.getCallbackQuery().getMessage().getChatId()));
            } catch (TelegramApiException e) {
                e.printStackTrace();
            }
        }
        if (update.hasMessage()) {
            if (update.getMessage().hasText()) {
                if (update.getMessage().getText().equals("/start") || update.getMessage().getText().equals("/start@MilLearnBot")) {
                    try {
                        execute(new SendMessage(update.getMessage().getChatId() + "", "Based on your preferences, our telegram bot will send you articles and tutorials that will help you to have more skills.\n\n" +
                                "How does this bot work?\n" +
                                "This bot has three commands:\n" +
                                "/start - if you are reading this text, then you have already selected this command. An introduction to this bot is shown here.\n" +
                                "/menu - if you press a menu command, you can choose where you want the random article from.\n" +
                                "/subjects - set subjects you are interested.\n" +
                                "/help - this explains how the bot works, as well as additional information."));
                        final CallbackQuery callbackQuery = update.getCallbackQuery();
                        final int chatId = callbackQuery.getFrom().getId();
                        userRepository.save(User.builder().chatId(chatId).build());
                    } catch (TelegramApiException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
        if (update.hasMessage()) {
            if (update.getMessage().hasText()) {
                if (update.getMessage().getText().equals("/help") || update.getMessage().getText().equals("/help@MilLearnBot")) {
                    try {
                        execute(new SendMessage(update.getMessage().getChatId() + "", "/start - if you are reading this text, then you have already selected this command. An introduction to this bot is shown here.\n" +
                                "/menu - if you press a menu command, you can choose where you want the random article from.\n" +
                                "/help - this explains how the bot works, as well as additional information.\n" +
                                "\n" +
                                "This telegram bot was developed by Suleyman Demirel University students for educational purposes.\n" +
                                "\n" +
                                "01.03.2021"));
                    } catch (TelegramApiException e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }

    private boolean enumContains(String subject) {
        try {
            Subject subjects = Subject.valueOf(subject);
        } catch (IllegalArgumentException ex) {
            return false;
        }
        return true;
    }

    private List<InlineKeyboardButton> createSubjectButtons() {
        Subject[] subjects = Subject.values();
        List<InlineKeyboardButton> result = new ArrayList<>();
        for (Subject subject : subjects) {
            InlineKeyboardButton button = new InlineKeyboardButton();
            button.setText(subject.getValue());
            button.setCallbackData(subject.getValue());
            result.add(button);
        }
        return result;
    }

    public static SendMessage sendInlineKeyBoardMessage(long chatId) {
        InlineKeyboardMarkup inlineKeyboardMarkup = new InlineKeyboardMarkup();
        InlineKeyboardButton inlineKeyboardButton1 = new InlineKeyboardButton();
        InlineKeyboardButton inlineKeyboardButton2 = new InlineKeyboardButton();
        inlineKeyboardButton1.setText("Wikipedia");
        inlineKeyboardButton1.setUrl(WIKI_URL.toString());
        inlineKeyboardButton2.setText("MediaWiki");
        inlineKeyboardButton2.setUrl(MEDIA_URL.toString());
        List<InlineKeyboardButton> keyboardButtonsRow1 = new ArrayList<>();
        List<InlineKeyboardButton> keyboardButtonsRow2 = new ArrayList<>();
        keyboardButtonsRow1.add(inlineKeyboardButton1);
        keyboardButtonsRow1.add(new InlineKeyboardButton().setText("WikiHow").setUrl("http://www.wikihow.com/Special:Randomizer"));
        keyboardButtonsRow2.add(inlineKeyboardButton2);
        List<List<InlineKeyboardButton>> rowList = new ArrayList<>();
        rowList.add(keyboardButtonsRow1);
        rowList.add(keyboardButtonsRow2);
        inlineKeyboardMarkup.setKeyboard(rowList);
        return new SendMessage().setChatId(chatId).setText("Choose where you want to select the article from").setReplyMarkup(inlineKeyboardMarkup);
    }
    @Override
    public String getBotUsername() {
        return USERNAME;
    }

    @Override
    public String getBotToken() {
        return TOKEN;
    }
}
