package kz.sdu.milleniumbot.app.user;


import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.annotations.Type;

import javax.persistence.*;
import javax.validation.constraints.NotNull;
import java.util.UUID;

@Data
@Entity
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Table(name = "user_details")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;
    @Column(name = "chat_id",unique = true, nullable = false)
    @NotNull
    private Integer chatId;
    @Type(type = "text[]")
    @Column(name = "subject", columnDefinition = "text[]")
    @Enumerated(EnumType.STRING)
    private Subject[] subject;
}
