package kz.sdu.milleniumbot.app.user;

public enum Subject {

    ArtsAndEntertainment("Искусство"),
    Cars("Машины");

    private final String value;

    Subject(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public String getName() {
        return name();
    }
}
