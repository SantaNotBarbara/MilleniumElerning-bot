create table user_details (
    id uuid not null constraint user_details_pk_id primary key,
    chat_id    INTEGER UNIQUE                NOT NULL,
    subject text[]
);